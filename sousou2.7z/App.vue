<script>
import init from '@/utils/init.js';
export default {
	onLaunch: function() {
		init.init();
		// uni.preloadPage({
		// 	url: `/pages/play/play`
		// });
	},
	onShow: function() {
		console.log('App Show');
	},
	onHide: function() {
		console.log('App Hide');
	}
};
</script>

<style lang="scss">
@import url('@/common/common.scss');
/*每个页面公共css */
::-webkit-scrollbar {
	display: none;
	width: 0 !important;
	height: 0 !important;
	-webkit-appearance: none;
	background: transparent;
}
</style>
