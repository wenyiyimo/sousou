const http = {
	async get(url, timeout = 5000, header = {}, ) {
		// console.log(url)
		if (url.startsWith('http')) {
			return new Promise((resolve, reject) => {
				uni.request({
					url: url,
					method: 'GET',
					header: header,
					timeout: timeout,
					success(response) {
						resolve(response.data);
					},
					fail(error) {
						reject(error)
					}
				})
			})
		} else {
			return JSON.parse(url)
		}

	}, // 匹配一次
	async matchOnce(key, html) {
		try {
			if (key == '') {
				return {
					flag: true,
					data: html,
					msg: '匹配完成'
				}
			}
			let re = new RegExp(key, 'g')
			let t = re.exec(html);
			if (!t) {
				html = JSON.stringify(html)
				re = new RegExp(key, 'g')
				t = re.exec(html);
			}
			return {
				flag: true,
				data: t[1].trim(),
				msg: '匹配完成'
			}
		} catch (e) {
			return {
				flag: false,
				data: String(e),
				msg: '匹配失败'
			}
		}
	},
	// 匹配所有
	async matchAll(key, html) {
		try {
			let re = new RegExp(key, 'g')
			let t;
			let results = [];
			while ((t = re.exec(html)) != null) {
				results.push(t[1].replace(new RegExp("\\\\", "g"), "").trim());
			};
			return {
				flag: true,
				data: results,
				msg: '匹配完成'
			}
		} catch (e) {
			//TODO handle the exception
			return {
				flag: false,
				data: String(e),
				msg: '匹配失败'
			}
		}
	},
	// json处理
	async matchjson(key, json) {
		try {
			if (key == '') {
				return {
					flag: true,
					data: json,
					msg: '匹配完成'
				}
			}
			let matchslice = key.split('.');
			let results = json;
			for (let slice of matchslice) {
				results = results[slice]
			}
			if (results) {
				return {
					flag: true,
					data: results,
					msg: '匹配完成'
				}
			} else {
				return {
					flag: false,
					data: String(e),
					msg: '获取失败'
				}
			}

		} catch (e) {
			return {
				flag: false,
				data: String(e),
				msg: '获取失败'
			}
		}
	},
	showToast(title, time = 1500, icon = "none") {
		uni.showToast({
			title: `\t${title}\t`,
			duration: time,
			icon: icon
		});
	},

	async search(site, key) {
		let url = site.search_url.replace('searchKey', key)
		let html = await this.get(url);
		let res_range = await this.matchOnce(site.search_range, html);
		if (res_range.flag) {
			let res_item = await this.matchAll(site.search_item, res_range.data);
			if (res_item.flag) {
				let datas = []
				for (let item of res_item.data) {
					let temp = {}
					let title = await this.matchOnce(site.search_title, item);
					let href = await this.matchOnce(site.search_href, item);
					let picture = await this.matchOnce(site.search_picture, item);
					let state = await this.matchOnce(site.search_state, item);
					if (href.flag) {
						temp.href = site.search_href_url + String(href.data).trim();
					} else {
						continue
					}
					if (title.flag) {
						temp.title = title.data.trim().replace(' ', '');
					} else {
						continue
					}
					if (state.flag) {
						temp.state = state.data.trim().replace(' ', '');
					} else {
						temp.state = '';
					}
					if (picture.flag) {
						temp.picture = site.search_picture_url + picture.data.trim();
					} else {
						temp.picture = '';
					}
					temp.site = site
					datas.push(temp)
				}
				if (datas.length != 0) {
					return {
						flag: true,
						data: datas
					}
				} else {
					return {
						flag: false,
						data: '获取失败!'
					}
				}
			} else {
				return {
					flag: false,
					data: '获取失败!'
				}
			}

		} else {
			return {
				flag: false,
				data: '获取失败!'
			}
		}
	},
	async play(site, url) {
		let jsondata = await this.get(url);
		let play_tag_range = await this.matchOnce(site.play_tag_range, jsondata);
		let play_tag_name = []
		if (play_tag_range) {
			play_tag_name = await this.matchAll(site.play_tag_name, play_tag_range.data)
		}
		let play_range = await this.matchOnce(site.play_range, jsondata);

		if (play_range.flag) {
			let datas = []
			let play_list = await this.matchAll(site.play_list, play_range.data)
			if (play_list.flag) {
				for (let j = 0; j < play_list.data.length; j++) {
					let item = play_list.data[j]
					let play_item = await this.matchAll(site.play_item, item);

					let parse = []
					if (play_item.flag) {
						let temp = []
						for (let i of play_item.data) {
							let name = await this.matchOnce(site.play_name, i)
							if (name.flag) {
								let href = await this.matchOnce(site.play_href, i)
								if (href.flag) {
									temp.push({
										name: name.data,
										url: site.play_href_url + href.data
									})
								}

							}

						}

						datas.push({
							line: play_tag_name.data[j] || `线路${j}`,
							parse: [],
							datas: temp,

						})
					}
				}

				return {
					flag: true,
					data: datas
				}
			} else {
				return {
					flag: false,
					data: '获取失败!'
				}
			}

		} else {
			return {
				flag: false,
				data: '获取失败!'
			}
		}
	}
}
export default http
