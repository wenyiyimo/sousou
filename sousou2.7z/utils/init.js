import site from './site.json'
import http from './http.js'
const init = {

	async init() {
		let search = uni.getStorageSync('search');
		if (!search) {
			uni.setStorageSync('search', [])
		}
		let video = uni.getStorageSync('video');
		if (!video) {
			let temp = {
				initialtime: 0,
				objectfit: 'contain',
				codec: 'hardware',
				playstrategy: 3,
				objectfitnum: 0,
				codecnum: 0,
				initialtimenum: [0, 0],
			};
			uni.setStorageSync('video', temp);
		}

		plus.device.setWakelock(true);
		// 保持屏幕常亮
		uni.setKeepScreenOn({
			keepScreenOn: true
		});

		let sWidth = uni.getStorageSync("sWidth");
		if (!sWidth) {
			uni.setStorageSync('sWidth', uni.getSystemInfoSync().screenWidth)
		}
		let sHeight = uni.getStorageSync('sHeight')
		if (!sHeight) {
			uni.setStorageSync('sHeight', uni.getSystemInfoSync().screenHeight)
		}
		let sites = uni.getStorageSync("sites");
		if (!sites) {
			uni.setStorageSync('sites', [site]);

		} else {
			if (sites.length == 1 && sites[0].SITE.length == 0) {
				sites[0].SITE = site.SITE
				uni.setStorageSync('sites', [site]);
			} else {
				for (let i = 0; i < sites.length; i++) {
					let item = sites[i]
					if (item.URL.trim() != '') {
						let jsondata = await http.get(item.URL);
						if (jsondata.SITE) {
							sites[i].SITE = jsondata.SITE
						}
						if (jsondata.TV) {
							sites[i].TV = jsondata.TV
						}
						if (jsondata.PLAY) {
							sites[i].PLAY = jsondata.PLAY
						}
					}
				}
				uni.setStorageSync('sites', sites);
			}

		}
		// 历史记录
		let history = uni.getStorageSync("history");
		if (!history) {
			uni.setStorageSync('history', []);
		}
		// 收藏
		let heart = uni.getStorageSync("heart");
		if (!heart) {
			uni.setStorageSync('heart', []);
		}
		let orientation = uni.getStorageSync("orientation");
		if (!orientation) {
			plus.screen.lockOrientation('portrait-primary')
			orientation = false
			uni.setStorageSync("orientation", orientation);
		} else {
			plus.screen.lockOrientation('landscape-primary')
		}

	},


}
export default init
