import http from '@/utils/http.js'
const cms = {
	async setsite(url, name) {
		if (url.endsWith("/v1.vod")) {
			let jsondata = await http.get(url + '/vodPhbAll');
			if (jsondata.data.list) {
				let classnames = []
				let classurls = []
				for (let item of jsondata.data.list) {
					classnames.push(item.vod_type_name)
					classurls.push(url + "?page=PAGE&type=" + item.vod_type_id)
				}
				return {
					flag: true,
					data: {
						"name": name,
						"id": "JSON",
						"isSearch": true,
						"isClass": true,
						"class_name": classnames.join('&&&'),
						"class_url": classurls.join('&&&'),
						"class_first": "1",
						"class_second": "2",
						"class_range": "data",
						"class_item": "list",
						"class_title": "vod_name",
						"class_href": "vod_id",
						"class_href_url": url + "/detail?vod_id=",
						"class_picture": "vod_pic",
						"class_picture_url": "",
						"class_state": "vod_remarks",
						"search_url": url + "?wd=searchKey",
						"search_range": "data",
						"search_item": "list",
						"search_title": "vod_name",
						"search_href": "vod_id",
						"search_href_url": url + "/detail?vod_id=",
						"search_picture": "vod_pic",
						"search_picture_url": "",
						"search_state": "vod_remarks",
						"play_tag_range": "",
						"play_tag_name": "",
						"play_range": "data",
						"play_list": "vod_play_list",
						"play_item": "urls",
						"play_name": "",
						"play_href": "",
						"play_href_url": "",
						"except": ""
					}
				}
			}
		} else if (url.indexOf("/vod/") != -1) {
			let jsondata = await http.get(url + '?ac=list');
			if (jsondata.class) {
				let classnames = []
				let classurls = []
				for (let item of jsondata.class) {
					classnames.push(item.type_name)
					classurls.push(url + "?ac=videolist&pg=PAGE&t=" + item.type_id)
				}
				return {
					flag: true,
					data: {
						"name": name,
						"id": "JSON",
						"isSearch": true,
						"isClass": true,
						"class_name": classnames.join('&&&'),
						"class_url": classurls.join('&&&'),
						"class_first": "1",
						"class_second": "2",
						"class_range": "",
						"class_item": "list",
						"class_title": "vod_name",
						"class_href": "",
						"class_href_url": "",
						"class_picture": "vod_pic",
						"class_picture_url": "",
						"class_state": "vod_remarks",
						"search_url": url + "?ac=videolist&wd=searchKey",
						"search_range": "",
						"search_item": "list",
						"search_title": "vod_name",
						"search_href": "",
						"search_href_url": "",
						"search_picture": "vod_pic",
						"search_picture_url": "",
						"search_state": "vod_remarks",
						"play_tag_range": "",
						"play_tag_name": "",
						"play_range": "",
						"play_list": "",
						"play_item": "",
						"play_name": "",
						"play_href": "",
						"play_href_url": "",
						"except": ""
					}
				}

			} else {
				return {
					flag: true,
					data: {
						"name": name,
						"id": "JSON",
						"isSearch": true,
						"isClass": true,
						"class_name": "追剧&&&电影&&&动漫&&&综艺",
						"class_url": url +
							"?ac=list&class=tvplay&page=PAGE&&&" + url +
							"?ac=list&class=movie&page=PAGE&&&" + url +
							"?ac=list&class=comic&page=PAGE&&&" + url +
							"?ac=list&class=tvshow&page=PAGE",
						"class_first": "1",
						"class_second": "2",
						"class_range": "",
						"class_item": "data",
						"class_title": "title",
						"class_href": "nextlink",
						"class_href_url": "",
						"class_picture": "pic",
						"class_picture_url": "",
						"class_state": "state",
						"search_url": url + "?ac=list&wd=searchKey",
						"search_range": "",
						"search_item": "data",
						"search_title": "title",
						"search_href": "nextlink",
						"search_href_url": "",
						"search_picture": "pic",
						"search_picture_url": "",
						"search_state": "state",
						"play_tag_range": "",
						"play_tag_name": "",
						"play_range": "",
						"play_list": "videolist",
						"play_item": "",
						"play_name": "",
						"play_href": "",
						"play_href_url": "",
						"except": ""
					}
				}
			}

		} else if (url.endsWith("/app/")) {
			let jsondata = await http.get(url + 'index_video');
			if (jsondata.list) {
				let classnames = []
				let classurls = []
				for (let item of jsondata.list) {
					classnames.push(item.type_name)
					classurls.push(url + "video?pg=PAGE&tid=" + item.type_id)
				}
				return {
					flag: true,
					data: {
						"name": name,
						"id": "JSON",
						"isSearch": true,
						"isClass": true,
						"class_name": classnames.join('&&&'),
						"class_url": classurls.join('&&&'),
						"class_first": "1",
						"class_second": "2",
						"class_range": "",
						"class_item": "list",
						"class_title": "vod_name",
						"class_href": "vod_id",
						"class_href_url": url + "video_detail?id=",
						"class_picture": "vod_pic",
						"class_picture_url": "",
						"class_state": "vod_remarks",
						"search_url": url + "/search?text=searchKey",
						"search_range": "",
						"search_item": "list",
						"search_title": "vod_name",
						"search_href": "vod_id",
						"search_href_url": url + "video_detail?id=",
						"search_picture": "vod_pic",
						"search_picture_url": "",
						"search_state": "vod_remarks",
						"play_tag_range": "",
						"play_tag_name": "",
						"play_range": "data",
						"play_list": "vod_url_with_player",
						"play_item": "",
						"play_name": "",
						"play_href": "",
						"play_href_url": "",
						"except": ""
					}
				}
			}

		} else if (url.endsWith("/v2/")) {
			return {
				flag: true,
				data: {
					"name": name,
					"id": "JSON",
					"isSearch": true,
					"isClass": true,
					"class_name": "追剧&&&电影&&&动漫&&&综艺",
					"class_url": url +
						"video?pg=PAGE&tid=2&&&" + url +
						"video?pg=PAGE&tid=1&&&" + url +
						"video?pg=PAGE&tid=4&&&" + url +
						"video?pg=PAGE&tid=3",
					"class_first": "1",
					"class_second": "2",
					"class_range": "",
					"class_item": "data",
					"class_title": "vod_name",
					"class_href": "vod_id",
					"class_href_url": url + "video_detail?id=",
					"class_picture": "vod_pic",
					"class_picture_url": "",
					"class_state": "vod_remarks",
					"search_url": url + "/search?text=searchKey",
					"search_range": "",
					"search_item": "data",
					"search_title": "vod_name",
					"search_href": "vod_id",
					"search_href_url": url + "video_detail?id=",
					"search_picture": "vod_pic",
					"search_picture_url": "",
					"search_state": "vod_remarks",
					"play_tag_range": "",
					"play_tag_name": "",
					"play_range": "data.vod_info",
					"play_list": "vod_url_with_player",
					"play_item": "",
					"play_name": "",
					"play_href": "",
					"play_href_url": "",
					"except": ""
				}
			}
		}
	},
	async search(site, key) {
		let url = site.search_url.replace('searchKey', key)
		let jsondata = await http.get(url);
		let res_range = await http.matchjson(site.search_range, jsondata);
		if (res_range.flag) {
			let res_item = await http.matchjson(site.search_item, res_range.data);
			if (res_item.flag) {
				let datas = []
				for (let item of res_item.data) {
					let temp = {}
					let title = await http.matchjson(site.search_title, item);
					let href = null
					if (site.search_href == '') {
						href = {
							flag: true,
							data: JSON.stringify(item)
						}
					} else {
						href = await http.matchjson(site.search_href, item);
					}
					let picture = await http.matchjson(site.search_picture, item);
					let state = await http.matchjson(site.search_state, item);
					if (href.flag) {
						temp.href = site.search_href_url + String(href.data).trim();
					} else {
						continue
					}
					if (title.flag) {
						temp.title = title.data.trim().replace(' ', '');
					} else {
						continue
					}
					if (state.flag) {
						temp.state = state.data.trim().replace(' ', '');
					} else {
						temp.state = '';
					}
					if (picture.flag) {
						temp.picture = site.search_picture_url + picture.data.trim();
					} else {
						temp.picture = '';
					}
					temp.site = site
					datas.push(temp)
				}
				if (datas.length != 0) {
					return {
						flag: true,
						data: datas
					}
				} else {
					return {
						flag: false,
						data: '获取失败!'
					}
				}

			} else {
				return {
					flag: false,
					data: '获取失败!'
				}
			}
		} else {
			return {
				flag: false,
				data: '获取失败!'
			}
		}
	},
	async getparse(url, jsondata) {
		if (url.indexOf('v1.vod') != -1) {
			let datas = [];
			let parse1 = await http.matchjson('player_info.parse', jsondata);
			let parse2 = await http.matchjson('player_info.parse2', jsondata);
			if (parse1.flag) {
				datas = [...datas, ...parse1.data.split(',')];
			}
			if (parse2.flag) {
				datas = [...datas, ...parse2.data.split(',')];
			}
			return Array.from(new Set(datas))
		}
	},
	async play(site, url) {
		let jsondata = await http.get(url);
		console.log(jsondata)
		// console.log(jsondata)
		let play_range = await http.matchjson(site.play_range, jsondata);
		if (play_range.flag) {
			let datas = []

			let play_list = await http.matchjson(site.play_list, play_range.data)
			if (play_list.flag) {
				if (url.indexOf("/v1.vod") != -1) {
					for (let item of play_list.data) {
						let play_item = await http.matchjson(site.play_item, item);

						let parse = await this.getparse(url, item);
						if (site.play_href_url != '') {
							parse = [...parse, ...site.play_href_url.split('&&&')];
						}
						if (!parse) {
							parse = []
						}
						if (play_item.flag) {
							datas.push({
								line: play_item.data[0].from,
								parse: Array.from(new Set(parse)) || [],
								datas: play_item.data,

							})
						} else {
							return {
								flag: false,
								data: '获取失败!'
							}
						}
					}
				} else if (site.search_url.indexOf("/vod/") != -1) {
					if (site.search_href == "") {
						let lines = play_list.data.vod_play_from.split("$$$")
						let temps = play_list.data.vod_play_url.split("$$$")
						let parse = []
						if (site.play_href_url != '') {
							parse = site.play_href_url.split("&&&")
						}
						for (let n = 0; n < lines.length; n++) {
							let temp = [];
							for (let item of temps[n].split("#")) {
								temp.push({
									name: item.split("$")[0],
									url: item.split("$")[1],
								})
							}
							datas.push({
								line: lines[n],
								parse: parse,
								datas: temp
							})
						}
					} else {

						let lines = Object.keys(play_list.data);
						for (let line of lines) {
							let temp = [];
							for (let item of play_list.data[line]) {
								temp.push({
									name: item.title,
									url: item.url
								})
							}
							datas.push({
								line: line,
								parse: [],
								datas: temp
							})
						}
					}

				} else if (url.indexOf("/app/") != -1) {

					for (let item of play_list.data) {
						let temp = []
						for (let i of item.url.split('#')) {
							temp.push({
								name: i.split('$')[0],
								url: i.split('$')[1]
							})
						}
						let parse = []
						if (item.parse_api.length != 0) {
							parse = [...parse, ...item.parse_api.split('\n')]
						}
						if (item.extra_parse_api && item.extra_parse_api.length != 0) {
							parse = [...parse, ...item.extra_parse_api.split('\n')]
						}
						if (site.play_href_url != '') {
							parse = [...parse, ...site.play_href_url.split('&&&')];
						}
						datas.push({
							line: item.name,
							parse: Array.from(new Set(parse)) || [],
							datas: temp
						})
					}
				} else if (url.indexOf("/v2/") != -1) {
					for (let item of play_list.data) {
						let temp = []
						for (let i of item.url.split('#')) {
							temp.push({
								name: i.split('$')[0],
								url: i.split('$')[1]
							})
						}
						let parse = []
						if (item.parse_api.length != 0) {
							parse = [...parse, ...item.parse_api.split('\n')]

						}
						if (item.extra_parse_api && item.extra_parse_api.length != 0) {

							parse = [...parse, ...item.extra_parse_api.split('\n')]
						}
						if (site.play_href_url != '') {
							parse = [...parse, ...site.play_href_url.split('&&&')];


						}
						datas.push({
							line: item.name,
							parse: Array.from(new Set(parse)) || [],
							datas: temp
						})
					}
				}
				return {
					flag: true,
					data: datas
				}
			} else {
				return {
					flag: false,
					data: '获取失败!'
				}
			}

		} else {
			return {
				flag: false,
				data: '获取失败!'
			}
		}
	}
}
export default cms
